# Section 1

Padatrad permet de traduire collectivement des textes et de les éditer depuis un navigateur web.


