# First section

Padatrad allows you to translate texts and edit them in a web browser in a collective way.

Padatrad vous permet de traduire d'une manière [collaborative]{default alt="collective"} des textes et de les éditer depuis un navigateur web. {.fr}