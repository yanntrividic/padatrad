# Section 1 {.source}

# {.target}

Padatrad permet de traduire collectivement des textes et de les éditer depuis un navigateur web. {.source}

{.target}


