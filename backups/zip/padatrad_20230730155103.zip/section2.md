# Section 2 {.source}

# Section 2 {.target .accepted}

Ce logiciel vous est proposé par les Éditions Burn~Août {.source}

{.target}
