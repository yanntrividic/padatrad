# Second section

# Seconde section {.fr .accepted}

This software is developed by Éditions Burn~Août.

{.fr}